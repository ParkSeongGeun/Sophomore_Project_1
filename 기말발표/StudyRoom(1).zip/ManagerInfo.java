package StudyRoom;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ManagerInfo {
	// 건물 정보 담기
	String[] builds = {"공학관", "생명공학관", "상허연구관"};
	ArrayList<ArrayList<ArrayList<String>>> tables = new ArrayList<>();
	ArrayList<ArrayList<String>> build1 = new ArrayList<>(); // 건물1: 공학관
	ArrayList<ArrayList<String>> build2 = new ArrayList<>(); // 건물2: 생명과학관
	ArrayList<ArrayList<String>> build3 = new ArrayList<>(); // 건물3: 상허연구관
	// 학생 정보 담기
	ArrayList<Student> members = new ArrayList<Student>();
	Scanner sc = new Scanner(System.in);
	// 학생 정보 삭제 시 담을 index
	int deleteStudent;
	// 공지 경로
	String NotificationFileCheck;
	//수정할 건물 선택
	int building_choice = 0;
	
	public ManagerInfo() {
		// 학생 정보 담는 과정 <- StudentInfo.java와 메서드 동일
		System.out.println("학생 정보 담는 중...");
		String filename = "src/StudyRoom/StudentInfoFile.txt";
		try (FileReader fileReader = new FileReader(filename);
				BufferedReader bufferedReader = new BufferedReader(fileReader)) {
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				//개행 문자별로 구분하도록
				String[] tokens = line.split("\t");
				
				try{
					Integer.parseInt(tokens[0]);
				}catch(Exception E){
					System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
					System.exit(0);
				}
				if(tokens[0].length()!=9||tokens[0].charAt(0)!='2'||tokens[0].charAt(1)!='0'
						||(tokens[0].charAt(2)!='1'&&tokens[0].charAt(2)!='2')||
						((tokens[0].charAt(2)=='2'&&tokens[0].charAt(3)>'3'))) {
					System.out.println("파일 형식에 오류가 있습니다.");
					System.out.println("프로그램을 종료합니다.");
					System.exit(0);
				}
				if (!tokens[1].matches("^[가-힣]+$")) {
		            // 영어, 공백, 한글 형식
		            if (tokens[1].matches(".*[a-zA-Z]+.*")
		            		||tokens[1].contains(" ")||tokens[1].contains("\t")
		            		||tokens[1].matches(".*\\d+.*")
		            		) {
		                System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
		                System.exit(0);
		            }
		            else{
		               System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
		               System.exit(0);
		            }
		         }
		         if(tokens[1].length()<2||tokens[1].length()>10) {
		            System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
		            System.exit(0);
		         }
		         if (tokens[2].length()<8 || tokens[2].length()>12) {
					System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
					System.exit(0);
				 }
				 else if (tokens[2].contains(" ")) {
					System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
					System.exit(0);
				 }
			   	 else{  //영문 숫자 말고 다른 것 입력하면 다시 입력
			 			for(int i=0; i<tokens[2].length(); i++) {
			 				int index = tokens[2].charAt(i);
							if(!((index >=48 && index <= 57)||(index >=97 && index <=122))) {
								System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
								System.exit(0);
							}
						}
				 }
				// tokens[0]엔 학번, tokens[1]엔 이름, tokens[2]엔 비밀번호
				Student student1 = new Student(tokens[0], tokens[1], tokens[2]);
				// members 객체 배열에 생성한 student1 넣기
				members.add(student1);
			}
			fileReader.close();
		}catch (Exception e) {
			System.out.println("회원 정보 파일이 없습니다.\n프로그램을 종료합니다.");
			System.exit(0);
		}
		// 파일 체크해서 ArrayList에 담는 코드
		System.out.println("빌딩 정보 담는 중...");
		build1 = file_check("src/StudyRoom/Room1_Information.txt");
		build2 = file_check("src/StudyRoom/Room2_Information.txt");
		build3 = file_check("src/StudyRoom/Room3_Information.txt");
		tables.add(build1);
		tables.add(build2);
		tables.add(build3); 
		// 공지 파일 불러오기
		NotificationFileCheck = "src/StudyRoom/Notification.txt"; // 실제 파일 경로로 대체해야 합니다.
        File file = new File(NotificationFileCheck);
        if (file.exists()) {
            System.out.println("파일이 존재합니다.");
        } else {
            System.out.println("파일이 존재하지 않습니다.");
        }
		ManagerInfo_Menu();
	}
	public void ManagerInfo_Menu() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1) 스터디룸 관리 2) 사용자 관리 ");
			System.out.println("3) 공지 설정 4) 로그아웃");
			System.out.print(">> ");
			try {
				int choice = Integer.parseInt(sc.nextLine().trim());
				// 문자열 입력 -> trim으로 공백 제거 -> 정수형으로 변환해서 choice에 담음
				// 입력받을 때 '__01' -> '1'
				switch (choice) {
				case 1:
					System.out.println("스터디룸 관리로 이동합니다.");
					// 스터디룸 관리로 접근
					Choose_building();
					break;
				case 2:
					System.out.println("사용자 관리로 이동합니다.");
					// 사용자 관리로 접근
					StudentEditing();
					break;
				case 3:
					System.out.println("공지 설정으로 이동합니다.");
					// 공지설정으로 접근
					WriteNotification();
					break;
				case 4:
					System.out.println("로그아웃되었습니다!");
					// 로그아웃해서 메뉴로 돌아가게
					return;
				default:
					System.out.println("1~4사이 숫자를 입력하세요!");
				}
			} catch (NumberFormatException E) {
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
	}
	
	public void Choose_building() {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<String>> build;
		
		System.out.println("관리할 건물을 선택하세요.");
		System.out.print("1) 공학관 ");
		System.out.println("2) 생명공학관");
		System.out.print("3) 상허연구관 ");
		System.out.println("4) 관리자 메뉴로 돌아가기");
		while(true) {
			System.out.print(">> ");
			try {
				building_choice = Integer.parseInt(sc.nextLine().trim());
				// 문자열 입력 -> trim으로 공백 제거 -> 정수형으로 변환해서 building_choice에 담음
				// 입력받을 때 '__01' -> '1'
				if(building_choice >= 1 && building_choice <= 3) {
					System.out.println("\'"+builds[building_choice-1]+"\'관리로 이동합니다");
					Studyroomediting(tables.get(building_choice-1));	
					return;
				}else if(building_choice == 4) {
					System.out.println("관리자 메뉴로 돌아갑니다.");
					return;
				}else
					System.out.println("해당 건물은 존재하지 않습니다.\n다시 입력하세요.");
			} catch (NumberFormatException E) {
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
		
		
	}
	
	public void Studyroomediting(ArrayList<ArrayList<String>> build) {
		// TODO Auto-generated method stub
		
		while(true) {
			System.out.print("1) 스터디룸 추가 ");
			System.out.println("2) 스터디룸 수정");
			System.out.print("3) 스터디룸 삭제 ");
			System.out.println("4) 예약 불가 설정");
			System.out.println("5) 관리자 메뉴로 돌아가기");
			System.out.print(">> ");
			try {
				int choice = Integer.parseInt(sc.nextLine().trim());
				// 문자열 입력 -> trim으로 공백 제거 -> 정수형으로 변환해서 choice에 담음
				// 입력받을 때 '__01' -> '1'
				if(choice >= 1 && choice <= 4) {
					switch(choice){
					case 1:
						System.out.println("\'스터디룸 추가\'로 이동합니다");
						Studyroom_add(build);
						break;
					case 2:
						System.out.println("\'스터디룸 수정\'으로 이동합니다");
						Studyroom_edit(build);
						break;
					case 3:
						System.out.println("\'스터디룸 삭제\'으로 이동합니다");
						Studyroom_delete(build);
						break;
					case 4:
						System.out.println("\'예약 불가 설정\'으로 이동합니다");
						Reservation_banmenu(build);
						break;
					}
				}else if(choice == 5) {
					System.out.println("관리자 메뉴로 돌아갑니다.");
					return;
				}else
					System.out.println("1~5사이 숫자를 입력하세요.");
			} catch (NumberFormatException E) {
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
	}
	
	public void Studyroom_add(ArrayList<ArrayList<String>> build) {
		
		ArrayList<String> addroom_Info = new ArrayList<String>();
		int roomNum = build.size() + 1; //추가될 호실 번호
		String choose = "";
		int member = 0;
		if(roomNum == 10) {
			System.out.println("현재 건물의 스터디룸은 9호실까지 존재하여 더이상 추가하실 수 없습니다.");
			return;
		}
		System.out.println("현재 관리자님이 추가할 호실은 "+ roomNum+ "번째 호실입니다.");
		System.out.println("호실 한도 인원을 설정해주세요.\n(스터디룸 관리 메뉴창 이동:q)");
		while(true) {
			System.out.print(">> ");
			try {
				choose = sc.nextLine().trim();
				member = Integer.parseInt(choose);
				// 입력받을 때 '__01' -> '1'
				if(member >= 2 && member <= 9) {
					while(true) {
						System.out.print(roomNum+"호실을 추가하겠습니까? (Y/N)\n>> ");
						choose = sc.nextLine();
						if(choose.equals("Y")) {
							addroom_Info.add(Integer.toString(roomNum));
							addroom_Info.add(Integer.toString(member));
							for(int i=0; i<6; i++)
								addroom_Info.add("0");
							build.add(addroom_Info);
							String filename = "src/StudyRoom/Room" + building_choice + "_Information.txt";
							file_change(filename, build);
							System.out.println("한도인원 "+ member+"명인 "+ roomNum+"호실이 "+ builds[building_choice-1]+"에 추가되었습니다.");
							Recent(building_choice);
							return;
						}else if(choose.equals("N")) {
							return;
						}else {
							System.out.println("다시 입력해주세요.");
						}
					}
				}else
					System.out.println("올바른 인원 수를 입력하세요!");
			} catch (NumberFormatException E) {
				if(choose.equals("q")) {
					System.out.println("스터디룸 추가를 종료합니다.");
					return;
				}
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
	}
	public void Studyroom_edit(ArrayList<ArrayList<String>> build) {
		
		int roomNum = 0; //수정될 호실 번호
		String choose = "";
		int member = 0;  //수정될 호실의 한도인원
		int roomIdx = 0; //스터디룸 파일에서 호실 인덱스
		ArrayList<String> room = new ArrayList<String>();
		String notice = "";
		
		System.out.println("수정할 호실을 입력하세요!\n(스터디룸 관리 메뉴창 이동:q)");
		while(true) {
			System.out.print(">> ");
			try {
				choose = sc.nextLine().trim();
				roomNum = Integer.parseInt(choose);
				if(roomNum>build.size() || roomNum<=0) {
					System.out.println("해당호실은 현재 존재하지 않습니다.\n다시 입력해주세요!");
					continue;
				}
				roomIdx = roomNum-1;
				room = build.get(roomIdx);
				int origin_num = Integer.parseInt(room.get(1)); //선택된 호실의 기존 한도인원
					System.out.println(roomNum+"호실은 현재 한도인원이 " +room.get(1)+"명입니다.");
					System.out.println("수정할 호실 한도인원을 입력하세요!");
					while(true) {
						try {
							System.out.print(">> ");
							choose = sc.nextLine().trim();
							member = Integer.parseInt(choose);
							// 입력받을 때 '__01' -> '1'
							if(member >= 2 && member <= 9) {
								if(member == Integer.parseInt(room.get(1))) {
									System.out.println("기존과 동일한 한도인원입니다.\n다시 입력해주세요!");
									continue;
								}
								while(true) {
									System.out.print(roomNum+"호실의 한도인원을 " + member +"명으로 수정하겠습니까? (Y/N)\n>> ");
									choose = sc.nextLine();
									if(choose.equals("Y")) {
										room.set(1, Integer.toString(member));
										if(member < origin_num) {
											for(int i = 2; i< room.size(); i++) {   ///*******txt파일에 인원이 저장이 안되어있어서 한도인원 비교 불가
												if(!room.get(i).equals("X") && Integer.parseInt(room.get(i)) > member) {
													notice += room.get(i) +" "+builds[building_choice-1] +" "+roomNum+"호실 "+
												(i-1)+"교시 예약이 취소되었습니다.\n";
													room.set(i, "0");
												}
											}
										}
										build.set(roomIdx, room);
										String filename = "src/StudyRoom/Room" + building_choice + "_Information.txt";
										file_change(filename, build);
										System.out.println(builds[building_choice-1] + " "+ roomNum + "호실("+member+"명)이 수정되었습니다.");
										System.out.println(notice);
										Recent(building_choice);
										return;
									}else if(choose.equals("N")) {
										return;
									}else {
										System.out.println("다시 입력해주세요.");
									}
								}
							}else
								System.out.println("올바른 인원 수를 입력하세요!");
						} catch (NumberFormatException E) {
							if(choose.equals("q")) {
								System.out.println("스터디룸 추가를 종료합니다.");
								return;
							}
							System.out.println("올바른 형식으로 입력하세요!");
						}
					}
			} catch (NumberFormatException E) {
				if(choose.equals("q")) {
					System.out.println("스터디룸 수정을 종료합니다.");
					return;
				}
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
	}
	public void Studyroom_delete(ArrayList<ArrayList<String>> build) {
		if(build.size() == 0)
		{
			System.out.println("현재 건물에는 더 이상 호실이 존재하지 않아 삭제하실 수 없습니다.");
			return;
		}
		String choose = "";
		int roomNum = 0; //삭제할 호실 번호
		int roomIdx = 0; //삭제할 호실 인덱스
		ArrayList<String> room = new ArrayList<String>();
		String notice = "";
		Recent(building_choice);
		while(true) {
			System.out.println("삭제할 호실을 입력하세요!\n(스터디룸 관리 메뉴창 이동:q)");
			System.out.print(">> ");
			try {
				choose = sc.nextLine().trim();
				roomNum = Integer.parseInt(choose);
				roomIdx = roomNum - 1;
				if(roomNum <= build.size() && roomNum > 0) {
					room = build.get(roomIdx);
					while(true) {
						System.out.print(roomNum+"호실을 삭제하겠습니까? (Y/N)\n>> ");
						choose = sc.nextLine();
						if(choose.equals("Y")) {
							for(int i = 2; i < room.size(); i++) {
								if(!room.get(i).equals("X") && Integer.parseInt(room.get(i)) != 0) {
									notice += room.get(i) +" "+builds[building_choice-1] +" "+roomNum+"호실 "+
									(i-1)+"교시 예약이 취소되었습니다.\n";
									}
							}
							build.remove(roomIdx);
							for(int i =roomIdx; i<build.size(); i++) {
								room = build.get(i);
								room.set(0, Integer.toString(i+1));
							}
							
							String filename = "src/StudyRoom/Room" + building_choice + "_Information.txt";
							file_change(filename, build);
							System.out.println(builds[building_choice-1] + " "+ roomNum + "호실이 삭제되었습니다.");
							System.out.println(notice);
							Recent(building_choice);
							return;
						} else if(choose.equals("N")) {
							return;
						} else {
							System.out.println("다시 입력해주세요.");
						}
					}
				}else {
					System.out.println("해당호실은 현재 존재하지 않습니다.\n다시 입력해주세요!");
					continue;
				}
			} catch (NumberFormatException E) {
				if(choose.equals("q")) {
					System.out.println("스터디룸 삭제를 종료합니다.");
					return;
				}
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
	}
	public void Reservation_banmenu(ArrayList<ArrayList<String>> build) {
		String choose;
		
		while(true) {
			System.out.println("1) 사용불가 설정 2) 사용가능 설정");
			System.out.println("3) 스터디룸 관리 메뉴로 돌아가기");
			System.out.print(">> ");
			try {
				int choice = Integer.parseInt(sc.nextLine().trim());
				if(choice<= 3 && choice >= 1) {
					switch(choice) {
					case 1:
						System.out.println("\'사용불가 설정\'으로 이동합니다.");
						Reservation_ban(build);
						break;
					case 2:
						System.out.println("\'사용가능 설정\'으로 이동합니다");
						Reservation_allow(build);
						break;
					case 3:
						System.out.println("\'스터디룸 관리 메뉴\'로 돌아갑니다.");
						return;
					}	
				}else {
					System.out.println("1~3사이의 숫자를 입력하세요!");
					continue;
				}
			}
			catch (NumberFormatException E) {
				System.out.println("올바른 형식으로 입력하세요!");
			}
		}
		
	}
	
	public void Reservation_ban(ArrayList<ArrayList<String>> build) {
		String choose = "";
		int roomNum = 0;
		int roomTim = 0;
		int idx;
		String notice = "";
		ArrayList<String> room = new ArrayList<String>();
		
		System.out.println("예약 불가 설정을 할 호실을 입력하세요!\n(스터디룸 예약 불가 설정 메뉴 이동:q)");
			while(true) {
				System.out.print(">> ");
				try {
					choose = sc.nextLine().trim();
					roomNum = Integer.parseInt(choose);
					if(roomNum<1 || roomNum>build.size()) {
						System.out.println("해당 호실은 현재 존재하지 않습니다.\n다시 입력해주세요!");
						continue;
					}
					room = build.get(roomNum-1);
					break;
				} catch (NumberFormatException E) {
					if(choose.equals("q")) {
						System.out.println("예약 불가 설정을 종료합니다.");
						return;
					}
					System.out.println("올바른 형식으로 입력하세요!");
				}
			}
			
			System.out.println("예약 불가 설정을 할 교시를 입력해주세요\n(스터디룸 예약 불가 설정 메뉴 이동: q)");
			while(true) {
				try {
					System.out.print(">> ");
					choose = sc.nextLine().trim();
					roomTim = Integer.parseInt(choose);
					idx = roomTim + 1;
					if(roomTim<1 || roomTim>6) {
						System.out.println("해당 교시는 존재하지 않습니다.\n다시 입력해주세요!");
						continue;
					}
					
	//				if(choose.length() > 9) {
	//					System.out.println("문자열 길이는 9를 초과할 수 없습니다.");
	//					continue;
	//				}
					if(room.get(idx).equals("X")) {
						System.out.println("해당 교시는 이미 예약 불가 설정이 되어 있습니다.\n다시 입력해주세요!");
						continue;
					}
					break;
				} catch (NumberFormatException E) {
					if(choose.equals("q")) {
						System.out.println("예약 불가 설정을 종료하고 스터디룸 관리 메뉴로 이동합니다.");
						return;
					}
					System.out.println("올바른 형식으로 입력하세요!");
				}
			}
			System.out.println(roomNum+"호실 "+roomTim+"교시에 예약 불가 설정을 추가하시겠습니까? (Y/N)");
			while(true) {
				System.out.print(">> ");
				choose = sc.nextLine();
				if(choose.equals("Y")) {
					if(Integer.parseInt(room.get(idx)) != 0)
						notice += room.get(idx) +" "+builds[building_choice-1] +" "+roomNum+"호실 "+
								roomTim+"교시 예약이 취소되었습니다.\n";
					room.set(idx, "X");
					build.set(roomNum-1, room);
					String filename = "src/StudyRoom/Room" + building_choice + "_Information.txt";
					file_change(filename, build);
					System.out.println(builds[building_choice-1] + " "+ roomNum + "호실 "+roomTim+"교시가 예약 불가 설정되었습니다.");
					System.out.println(notice);
					Recent(building_choice);
					return;
				}
				else if(choose.equals("N")) {
					return;
				}else {
					System.out.println("올바른 형식으로 입력해주세요!");
				}
				
			}
			
		
	}
	
	public void Reservation_allow(ArrayList<ArrayList<String>> build) {
		String choose = "";
		int roomNum = 0;
		int roomTim = 0;
		int idx;
		String notice = "";
		ArrayList<String> room = new ArrayList<String>();
		
		System.out.println("예약 불가 해제 설정을 할 호실을 입력하세요!\n(스터디룸 예약 불가 설정 메뉴 이동:q)");
			while(true) {
				System.out.print(">> ");
				try {
					choose = sc.nextLine().trim();
					roomNum = Integer.parseInt(choose);
					if(roomNum<1 || roomNum>build.size()) {
						System.out.println("해당 호실은 현재 존재하지 않습니다.\n다시 입력해주세요!");
						continue;
					}
					room = build.get(roomNum-1);
					break;
				} catch (NumberFormatException E) {
					if(choose.equals("q")) {
						System.out.println("예약 불가 설정을 종료합니다.");
						return;
					}
					System.out.println("올바른 형식으로 입력하세요!");
				}
			}
			
			System.out.println("예약 불가 해제 설정을 할 교시를 입력해주세요\n(스터디룸 예약 불가 설정 메뉴 이동: q)");
			while(true) {
				try {
					System.out.print(">> ");
					choose = sc.nextLine().trim();
					roomTim = Integer.parseInt(choose);
					idx = roomTim + 1;
					if(roomTim<1 || roomTim>6) {
						System.out.println("해당 교시는 존재하지 않습니다.\n다시 입력해주세요!");
						continue;
					}
					
	//				if(choose.length() > 9) {
	//					System.out.println("문자열 길이는 9를 초과할 수 없습니다.");
	//					continue;
	//				}
					if(!(room.get(idx).equals("X"))) {
						System.out.println("해당 교시는 예약 불가 설정이 되어있지 않습니다.\n다시 교시를 입력해주세요!");
						continue;
					}
					break;
				} catch (NumberFormatException E) {
					if(choose.equals("q")) {
						System.out.println("예약 불가 설정을 종료하고 스터디룸 관리 메뉴로 이동합니다.");
						return;
					}
					System.out.println("올바른 형식으로 입력하세요!");
				}
			}
			System.out.println(roomNum+"호실 "+roomTim+"교시에 예약 불가 설정을 취소하시겠습니까? (Y/N)");
			while(true) {
				System.out.print(">> ");
				choose = sc.nextLine();
				if(choose.equals("Y")) {
					room.set(idx, "0");
					build.set(roomNum-1, room);
					
					String filename = "src/StudyRoom/Room" + building_choice + "_Information.txt";
					file_change(filename, build);
					System.out.println(builds[building_choice-1] + " "+ roomNum + "호실 "+roomTim+"교시가 예약 불가 설정이 취소되었습니다.");
					System.out.println(notice);
					Recent(building_choice);
					return;
				}
				else if(choose.equals("N")) {
					return;
				}else {
					System.out.println("올바른 형식으로 입력해주세요!");
				}
				
			}
			
	}
	
	public void Recent(int buildnum) {
		System.out.println();
		if(buildnum == 1) {
			System.out.println("공학관");
		}
		else if(buildnum == 2) {
			System.out.println("생명과학관");
		}
		else {
			System.out.println("상허연구관");
		}
		int building = buildnum - 1;
		if(tables.get(building).size() == 0) {
			System.out.println("이 건물엔 현재 호실이 없습니다.");
			return;
		}
		System.out.println("-------------------------------------------");
		System.out.print(" 호실 한도인원  1교시(10~12시)  2교시(12~14시)  3교시(14~16시)  4교시(16~18시)  5교시(18~20시)  6교시(20~22시)\n");
		for(int i=0;i<tables.get(building).size();i++) {	
			for(int j=0;j<8;j++) {
				if(j>=2) {
					if(tables.get(building).get(i).get(j).equals("0")) {
						System.out.print("X             ");
					}
					else if(tables.get(building).get(i).get(j).equals("X")) {
						System.out.print("F             ");
					}
					else {
						System.out.print("O             ");
					}
				}
				else if(j==0) {
					System.out.print(tables.get(building).get(i).get(j)+"호실   ");
				}
				else if(j==1) {
					System.out.print(tables.get(building).get(i).get(j)+"        ");
				}
			} 
			System.out.println();
		}
		System.out.println("O: 예약 되어 있음 X: 비어있음 예약 가능 F: 예약 불가");
		System.out.println("-------------------------------------------");
	}
	
	public void StudentEditing() {
		int check=0;
		while(true) {
			System.out.println("삭제할 학번을 입력하세요.");
			System.out.println("(관리자 메뉴창으로 이동 : q)");
			System.out.print(">> ");
			String inputid = sc.nextLine();
			//일단 trim안쓰고 -> 기획서에 명시가 안되어있어서
			if(inputid.contentEquals("q")) {
				System.out.println("관리자 메뉴로 돌아갑니다.");
				break;
			}
			try {
				Integer.parseInt(inputid);
			}catch(Exception E) {
				System.out.println("형식에 맞게 입력하세요!");
				continue;
			}
			if(inputid.length()!=9||inputid.charAt(0)!='2'||inputid.charAt(1)!='0'
					||(inputid.charAt(2)!='1'&&inputid.charAt(2)!='2')||
					((inputid.charAt(2)=='2'&&inputid.charAt(3)>'3'))) {
				System.out.println("형식에 맞게 입력하세요!");
				continue;
			} 
			if(!finduser(inputid)) { // 기존 MemberInfo에서와 동일
				System.out.println("해당 학번 정보를 삭제하시겠습니까?");
				System.out.println("(Y/N)");
				while(true) {
					System.out.print(">> ");
					String ans = sc.nextLine();
					if(ans.equals("Y")) {
						// 삭제
						String deletestudent = members.get(deleteStudent).getUid();
						members.remove(deleteStudent);
						System.out.println("해당 학번 삭제 완료");
						// 파일 변형
						try {
				            BufferedWriter writer = new BufferedWriter(new FileWriter("src/StudyRoom/StudentInfoFile.txt", false));
				            for (Student student : members) {
				            	//System.out.println(student.getUid() + "\t" + student.getPwd() + "\t" + student.getName());
				                writer.write(student.getUid() + "\t" + student.getName() + "\t" + student.getPwd() + "\n");
				            }
				            writer.close();
				        } catch (IOException e) {
				            e.printStackTrace();
				        }
						for(int i=0;i<3;i++) {
							for(int j=0;j<tables.get(i).size();j++) {
								for(int k=2;k<8;k++) {
									if(tables.get(i).get(j).get(k).equals(deletestudent)) {
										System.out.println(deletestudent + " " + builds[i] + " " + (j+1) + "호실 " + (k-1) + "교시 예약이 취소되었습니다.");
										tables.get(i).get(j).remove(k);
										tables.get(i).get(j).add(k, "0");
										String filename = "src/StudyRoom/Room" + (i+1) + "_Information.txt";
										file_change(filename, tables.get(i));
									}
								}
							}
						}
						check=1;
						break;
					}
					if(ans.equals("N")) {
						// 삭제 X
						check=1;
						System.out.println("관리자 메뉴로 돌아갑니다.");
						break;
					}
					System.out.println("Y 또는 N을 입력하세요!");
				}
			}
			else {
				System.out.println("해당 학번은 존재하지 않습니다!");
			}
			if(check==1) {
				break;
			}
		}	
	}
	private boolean finduser(String uid) {
		int i=0;
		for(Student st1 : members) {
			if(st1.getUid().equals(uid)) {
				deleteStudent=i;
				return false;
			}
			i++;
		}
		return true;
	}
	public void WriteNotification() {
		System.out.println("공지를 입력하세요");
		try {
            Scanner scanner = new Scanner(System.in);
            System.out.print("수정할 내용을 입력하세요: ");
            String inputText = scanner.nextLine();
            System.out.println("공지를 수정하시겠습니까? (Y/N)");
            while(true) {
            	System.out.print(">> ");
				String choose = sc.nextLine();
				if(choose.equals("Y")) {
					 BufferedWriter writer = new BufferedWriter(new FileWriter(NotificationFileCheck, false));
			            writer.write(inputText);
			            System.out.println("공지가 수정되었습니다.");
			            writer.close();
					return;
				}
				else if(choose.equals("N")) {
					return;
				}else {
					System.out.println("올바른 형식으로 입력해주세요!");
				}
				
			}
          
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public ArrayList<ArrayList<String>> file_check(String filename) { // 파일 체크 및 파일 list로 전환 함수
		ArrayList<ArrayList<String>> tempbuild = new ArrayList<>(); // 반환할 리스트
		try (FileReader fileReader = new FileReader(filename);
				BufferedReader bufferedReader = new BufferedReader(fileReader)) {
			String line; // 줄 읽어오는 변수
			int check=0; // 줄수 체크용
			while ((line = bufferedReader.readLine()) != null) {
				//개행 문자별로 구분하도록
				// 선언한 배열 안에 split으로 구분하여 하나씩 넣기
				String[] tokens = null;
				if(check == 9) { // 파일 9줄까지 체크했는데 또 읽을 줄이 있을 경우
					System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
				}
				else {
					tokens = line.split(" ");
					try {
						Integer.parseInt(tokens[0]); // 첫 숫자 읽었을 때 숫자 변환이 안될 때(공백 있을 경우, 숫자가 아닐 경우)
					} catch(Exception E) {
						System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
						System.exit(0);
					}
					if(tokens.length != 8) { // 6교시를 초과해서 문자가 더 있을 때
						System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
						System.exit(0);
					}
				}
				for(int i=0;i<8;i++) {
					if(i == 0) { 
						if(Integer.parseInt(tokens[0]) != check+1) { // 각 줄에 맞는 호실이 아닐 때 ex) 첫 번째 줄인데 1호실 아니고 2호실일 때
							System.out.println(tokens[0]);
							System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
							System.exit(0);
						}
					}
					else if(i == 1) { // 한도 인원 부분 체크
						try {
							Integer.parseInt(tokens[i]); // 호실 부분 읽었는데 정수 변환 안될 때(공백, 숫자 아님)
						} catch(Exception E) {
							System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
							System.exit(0);
						}
						if(Integer.parseInt(tokens[i]) < 2 || Integer.parseInt(tokens[i]) > 9) { // 한도 인원 수가 2 이상 9 이하가 아닐 때
							System.out.println("파일 형식에 오류가 있습니다.\n프로그램을 종료합니다.");
							System.exit(0);
						}
					}
					else {
						if(!tokens[i].equals("0") && !tokens[i].equals("X")) { // 각 교시 예약 정보 부분 확인 아래는 학번 형식 안맞을 때 조건은 0(예약 안되어 있음), X(예약 불가) 아닐 때
							 if(tokens[i].length()!=9||tokens[i].charAt(0)!='2'||tokens[i].charAt(1)!='0'
						               ||(tokens[i].charAt(2)!='1'&&tokens[i].charAt(2)!='2')||
						               ((tokens[i].charAt(2)=='2'&&tokens[i].charAt(3)>'3'))) {
								 System.out.println("파일 형식에 오류가 있습니다. 프로그램을 종료합니다.");
								 System.exit(0);
							 }
						}
					}
				}
				ArrayList<String> temp = new ArrayList<>();
				for(String a : tokens) {
					temp.add(a);
				}
				tempbuild.add(temp);
				check++;
			}
			fileReader.close();
		} catch (IOException e) {
			System.out.println("예약 정보 파일이 없습니다. 프로그램을 종료합니다.");
			System.exit(0);
		}
		return tempbuild;
	}
	
	public void file_change(String filename, ArrayList<ArrayList<String>> build) {
		try (FileOutputStream fos = new FileOutputStream(filename, false)) {

        } catch (IOException e) {
            e.printStackTrace();
        }
		try {
			PrintWriter writer = new PrintWriter(filename);
			for(int i=0;i<build.size();i++) {
				for(int j=0;j<8;j++) {
					writer.write(build.get(i).get(j)+" ");
				}
				if(i!=build.size()-1)
				writer.write("\n");
			}
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
